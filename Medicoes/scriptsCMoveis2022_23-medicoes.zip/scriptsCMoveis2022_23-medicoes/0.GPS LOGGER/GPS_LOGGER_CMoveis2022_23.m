% ========================================================================
% C. Móveis 2022/23 - AARONIA GPS LOGGER - João R. Reis
% thanks to prof. Nuno Leonor for making this code available!
% ========================================================================
clc
clear
% ========================================================================
% Clear existing connections
% ========================================================================
if(~isempty(instrfind))
    fclose(instrfind);
end

% =======================================================================
% GPS Device Configurations
% =======================================================================
GPS_DEV.COM_PORT = 'COM3';             % <<< -- Define your COM Port (There are 2 COM Ports - One for GPS other for Accelerometer)
GPS_DEV.BAUDRATE = 625000;
GPS_DEV.TERMINATOR = 'CR/LF';
GPS_DEV.StopBits = 2;

% ========================================================================
% Open GPS Device
% ========================================================================
GPS_DEV.INSTRUMENT = serial(GPS_DEV.COM_PORT);
GPS_DEV.INSTRUMENT.Baudrate = GPS_DEV.BAUDRATE;
GPS_DEV.INSTRUMENT.Terminator = GPS_DEV.TERMINATOR;
GPS_DEV.INSTRUMENT.StopBits = GPS_DEV.StopBits;
fopen(GPS_DEV.INSTRUMENT);
fprintf(GPS_DEV.INSTRUMENT,'$PAAG,MODE,START');


% ========================================================================
% Start measurement
% ========================================================================

fileName = 'exemploFicheiroMedição.txt';
 
while(1)
    % ========================================================================
    % GPS READING
    % ========================================================================
    GPS_String=fscanf(GPS_DEV.INSTRUMENT);
    
    if(contains(GPS_String,'GPGGA'))
        [GPS_READING] = Process_GPS_String(GPS_String);
        
        %%% NOTE %%%
        % ptxdBm = write here a function to read from Spectrum Analyser
        ptxdBm = 10*rand(); % dummy power

        %%% Display in Console line %%%
        disp([['Elapsed time ' num2str(toc)] 's,' ' Lat: ' num2str(GPS_READING.LAT) ' Long: ' num2str(GPS_READING.LON) ', Power: ' num2str(ptxdBm)]);
        
        %%% Save Data To File %%%
        fileID=fopen(fileName,'a');
        fprintf(fileID,'%s, %s, %s\n',GPS_READING.LAT, GPS_READING.LON, ptxdBm);
        fclose(fileID);
        tic
    end
end



